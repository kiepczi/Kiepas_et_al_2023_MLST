# **README.md - 02_run_MLST.sh**
This script was used to run MLST tool to identify alleles and sequence types. 

## **Arguments**
To run the script, pass the following arguments:


- `arg1` - Path to file (str) to which novel sequences will be saved to
- `arg2` - Path to file (str) with input genomes
- `arg3` - MLST scheme 


