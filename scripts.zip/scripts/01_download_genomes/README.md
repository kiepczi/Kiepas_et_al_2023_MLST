# **README.md - download_genomes.sh**

This scipt was used to download *Streptomyces* genomic sequences used in this manuscipt using ncbi-genome-download.

## **Arguments**
To run the script, pass the following arguments:

- `arg1` - genra of interest. Here we used `Streptomyces` to download all avaliable *Streptomyces* genomes.
- `arg2` - Path to output file.

