library('ggplot2')
library(ggplot2)
library(dplyr)
library(tidyr)
library(ggpubr)
library(ggplot2)
library('ggExtra')

#Generate Suplementary Figure 28. Genome count per ST bs Unique names per ST
data <- read.csv("ST_ancillary_info.csv") #Loading data

print(data)
pdf(file='../supplementary_file_28.pdf', width=12, height=8)

p <- ggplot(data, aes(x=Genome_Count, y=Unique_Species_Names_Count)) + 
  scale_x_continuous(breaks = seq(0, 30, 1), name ="Genome count per ST") +
  scale_y_continuous(breaks = seq(1, 4, 1), name="Unique NCBI species names per ST") + 
  geom_count(aes(colour=after_stat(n)), alpha=0.4)  + 
  scale_size_area(max_size=20) + 
  theme(legend.position = "none") +
  scale_color_viridis_c() +
  theme(legend.position = "none") + 
  coord_cartesian(clip = "off")
p + geom_text(data = ggplot_build(p)$data[[1]], 
              aes(x, y, label = n), color = "black")
dev.off()



#Generate Genome identity pyANI plots for ST comparisions (Figure 5)
data <- read.csv("pyani_coverage_identity_ST_comparisions_df.csv")
data2 <- data[!data$unique_taxa_names_per_ST %in% c('3', '2'), ]
data3 <- data[!data$unique_taxa_names_per_ST %in% c('1'), ]

pdf(file='main_text_figures/identity_STs.pdf', width=30, height=15)

p1<-ggplot(data2, aes(x=cluster_id, y=identity, col=comparision_type_genus)) +geom_jitter(alpha=0.4)  + facet_wrap(unique_taxa_names_per_ST ~., scales = 'free_x', nrow=4, shrink=TRUE, dir='h') + scale_y_continuous(name="Genome Identity (%)") +
  scale_x_continuous(breaks = seq(0, 100, 2), name ="") + theme(legend.position="none") +
  scale_color_manual(values=c( "#76B947", "#FF0000")) +
  geom_hline(yintercept = 0.95, linetype = "dashed", color = "red")

p2<-ggplot(data3, aes(x=cluster_id, y=identity, col=comparision_type_genus)) +geom_jitter(alpha=0.4) + 
  
  facet_wrap(unique_taxa_names_per_ST~., scales = 'free_x', nrow=1, shrink=TRUE, dir='h') + scale_y_continuous(name="") +
  scale_x_continuous(breaks = seq(0, 30, 1), name ="Cluster ID") + theme(legend.position="none") +
  scale_color_manual(values=c( "#76B947", "#FF0000"))+
  geom_hline(yintercept = 0.95, linetype = "dashed", color = "red")

p5<-ggarrange(p1, p2,
              ncol = 1, nrow = 2, heights = c(1, 1)) 
plot(p5)
dev.off()



#Generate Genome coverage pyANI plots for ST comparisions
data <- read.csv("pyani_coverage_identity_ST_comparisions_df.csv")
data2 <- data[!data$unique_taxa_names_per_ST %in% c('3', '2'), ]
data3 <- data[!data$unique_taxa_names_per_ST %in% c('1'), ]

pdf(file='main_text_figures/coverage_STs.pdf', width=30, height=15)

p1<-ggplot(data2, aes(x=cluster_id, y=coverage, col=comparision_type_genus)) +geom_jitter(alpha=0.4)  + facet_wrap(unique_taxa_names_per_ST ~., scales = 'free_x', nrow=4, shrink=TRUE, dir='h') + scale_y_continuous(name="Genome Coverage (%)") +
  scale_x_continuous(breaks = seq(0, 100, 2), name ="") + theme(legend.position="none") +
  scale_color_manual(values=c( "#76B947", "#FF0000")) +
  geom_hline(yintercept = 0.5, linetype = "dashed", color = "red")

p2<-ggplot(data3, aes(x=cluster_id, y=coverage, col=comparision_type_genus)) +geom_jitter(alpha=0.4) + 
  
  facet_wrap(unique_taxa_names_per_ST~., scales = 'free_x', nrow=1, shrink=TRUE, dir='h') + scale_y_continuous(name="") +
  scale_x_continuous(breaks = seq(0, 30, 1), name ="Cluster ID") + theme(legend.position="none") +
  scale_color_manual(values=c( "#76B947", "#FF0000")) +
  geom_hline(yintercept = 0.5, linetype = "dashed", color = "red")

p5<-ggarrange(p1, p2,
              ncol = 1, nrow = 2, heights = c(1, 1)) 
plot(p5)
dev.off()



#Generate Genome coverage pyANI plots for connected components
data <- read.csv("pyani_coverage_identity_df.csv")

data2 <- data[!data$unique_taxa_names_per_connected_component %in% c('13', '11','7', '5', '4', '3', '6'), ]
data3 <- data[!data$unique_taxa_names_per_connected_component %in% c('1', '2'), ]
pdf(file='../supplementary_file_29.pdf', width=30, height=15)


p1<-ggplot(data2, aes(x=cluster_id, y=coverage, col=comparision_type_species)) +geom_jitter(alpha=0.2)  + 
  facet_wrap(unique_taxa_names_per_connected_component ~., scales = 'free_x', nrow=2, shrink=TRUE, dir='h') + 
  scale_y_continuous(name="Genome Coverage (%)") +
  scale_x_continuous(breaks = seq(0, 100, 5), name ="") + theme(legend.position="none") +
  geom_hline(yintercept = 0.5, linetype = "dashed", color = "red")

p2<-ggplot(data3, aes(x=cluster_id, y=coverage, col=comparision_type_species)) +geom_jitter(alpha=0.2) + 
  facet_wrap(unique_taxa_names_per_connected_component ~., scales = 'free_x', nrow=2, shrink=TRUE, dir='h') + 
  scale_y_continuous(name="") +
  scale_x_continuous(breaks = seq(0, 10, 1), name ="Cluster ID") + theme(legend.position="none")+
  geom_hline(yintercept = 0.5, linetype = "dashed", color = "red")

p4<-ggarrange(p1, p2, ncol = 1, nrow = 2, heights = c(1, 1, 1)) 
plot(p4)
dev.off()

#Generate Genome identity pyANI plots for connected components
data <- read.csv("pyani_coverage_identity_df.csv")

data2 <- data[!data$unique_taxa_names_per_connected_component %in% c('13', '11','7', '5', '4', '3', '6'), ]
data3 <- data[!data$unique_taxa_names_per_connected_component %in% c('1', '2'), ]
pdf(file='../supplementary_file_30.pdf', width=30, height=15)


p1<-ggplot(data2, aes(x=cluster_id, y=identity, col=comparision_type_genus)) +geom_jitter(alpha=0.2)  + 
  facet_wrap(unique_taxa_names_per_connected_component ~., scales = 'free_x', nrow=2, shrink=TRUE, dir='h') + 
  scale_y_continuous(name="Genome Identity (%)") +
  scale_x_continuous(breaks = seq(0, 50, 5), name ="") + theme(legend.position="none") +
  geom_hline(yintercept = 0.95, linetype = "dashed", color = "red") +
  scale_color_manual(values=c( "purple", "orange"))

p2<-ggplot(data3, aes(x=cluster_id, y=identity, col=comparision_type_genus)) +geom_jitter(alpha=0.2) + 
  
  facet_wrap(unique_taxa_names_per_connected_component~., scales = 'free_x', nrow=2, shrink=TRUE, dir='h') + 
  scale_y_continuous(name="") +
  scale_x_continuous(breaks = seq(0, 10, 1), name ="Cluster ID") + theme(legend.position="none") +
  geom_hline(yintercept = 0.95, linetype = "dashed", color = "red") +
  scale_color_manual(values=c( "purple", "orange")) 

p4<-ggarrange(p1, p2,
              ncol = 1, nrow = 2, heights = c(1, 1, 1)) 
plot(p4)
dev.off()



#Generate Genome coverage pyANI plots for shared name comparisions
data <- read.csv("pyani_coverage_identity_shared_NCBI_names_df.csv")
data2 <- data[!data$connected_components_count %in% c('2', '3', '4'), ]
data3 <- data[!data$connected_components_count %in% c('1'), ]


pdf(file='main_text_figures/identity_shared_name.pdf', width=30, height=15)
# Modify the ggplot code
p1 <- ggplot(data2, aes(x = organism, y = identity, col = comparision_type_genus)) +
  geom_jitter(alpha = 0.4) +
  facet_wrap(connected_components_count ~ ., scales = 'free_x', nrow = 4, shrink = TRUE, dir = 'h') +
  scale_y_continuous(name = "Genome Identity (%)",  limits = c(0.8, 1.0)) +
  theme(legend.position = "none") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1)) +
  scale_color_manual(values = c("orange", "purple")) +
  geom_hline(yintercept = 0.95, linetype = "dashed", color = "red")

p2 <- ggplot(data3, aes(x = organism, y = identity, col = comparision_type_genus)) +
  geom_jitter(alpha = 0.4) +
  facet_wrap(connected_components_count ~ ., scales = 'free_x', nrow = 1, shrink = TRUE, dir = 'h') +
  scale_y_continuous(name = "Genome Identity (%)",  limits = c(0.8, 1.0)) +
  theme(legend.position = "none") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1)) +
  scale_color_manual(values = c("purple", "orange")) +
  geom_hline(yintercept = 0.95, linetype = "dashed", color = "red")

p5 <- ggarrange(p1, p2, ncol = 1, nrow = 2, heights = c(1, 1))
plot(p5)
dev.off()



#Generate Genome coverage pyANI plots for shared name comparisions
data <- read.csv("pyani_coverage_identity_shared_NCBI_names_df.csv")
data2 <- data[!data$connected_components_count %in% c('2', '3', '4', '5'), ]
data3 <- data[!data$connected_components_count %in% c('1'), ]



pdf(file='main_text_figures/coverage_shared_name.pdf', width=30, height=15)

p1<-ggplot(data2, aes(x=organism, y=coverage, col=comparision_type_species)) +
  geom_jitter(alpha=0.4)  + 
  facet_wrap(connected_components_count ~., scales = 'free_x', nrow=4, shrink=TRUE, dir='h') + 
  scale_y_continuous(name="Genome Coverage (%)",  limits = c(0.1, 1.0)) +
  theme(legend.position="none") +scale_color_manual(values=c( "#f4968f", "#17c3c6")) + 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) +
  geom_hline(yintercept = 0.5, linetype = "dashed", color = "red")

p2<-ggplot(data3, aes(x=organism, y=coverage, col=comparision_type_species)) +geom_jitter(alpha=0.4) + 
  
  facet_wrap(connected_components_count~., scales = 'free_x', nrow=1, shrink=TRUE, dir='h') + scale_y_continuous(name="") +
  theme(legend.position="none") +
  scale_y_continuous(name="Genome Coverage (%)",  limits = c(0.1, 1.0)) + 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1)) +
  geom_hline(yintercept = 0.5, linetype = "dashed", color = "red")

p5<-ggarrange(p1, p2,
              ncol = 1, nrow = 2, heights = c(1, 1)) 
plot(p5)
dev.off()








#Generate Suplementary Figure 31. Number of genomes per pyANI species vs number of unique NCBU names per pyANI species
data <- read.csv("pyANI_species_count_info.csv") #Loading data

print(data)
pdf(file='../supplementary_file_31.pdf', width=18, height=10)

p <- ggplot(data, aes(x=Genome_Count, y=unique_ST_count)) + 
  scale_x_continuous(breaks = seq(1, 61, 2), name ="Number of genomes per ANIm species") +
  scale_y_continuous(breaks = seq(1, 46, 2), name="Number of unique STs per ANIm species") + 
  geom_count(aes(colour=after_stat(n)), alpha=0.4)  + 
  scale_size_area(max_size=20) + 
  theme(legend.position = "none") +
  scale_color_viridis_c() +
  theme(legend.position = "none") + 
  coord_cartesian(clip = "off")
p + geom_text(data = ggplot_build(p)$data[[1]], 
              aes(x, y, label = n), color = "black")
dev.off()





#Generate Suplementary Figure 8. Number of genomes per pyANI species vs nnumber of unique NCBU names per pyANI species
data <- read.csv("pyANI_species_count_info.csv") #Loading data

print(data)
pdf(file='../supplementary_file_32.pdf', width=18, height=10)

p <- ggplot(data, aes(x=Genome_Count, y=Unique_names_Count)) + 
  scale_x_continuous(breaks = seq(0, 100, 2), name ="Number of genomes per ANIm species") +
  scale_y_continuous(name="Number of unique NCBI species names per ANIm species") + 
  geom_count(aes(colour=after_stat(n)), alpha=0.4)  + 
  scale_size_area(max_size=10) + 
  theme(legend.position = "none") +
  scale_color_viridis_c() +
  theme(legend.position = "none") + 
  coord_cartesian(clip = "off")
p + geom_text(data = ggplot_build(p)$data[[1]], 
              aes(x, y, label = n), color = "black")
dev.off()

